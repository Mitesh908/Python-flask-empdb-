from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

app = Flask(__name__)
CORS(app)
DATABASE = 'employee.db'

# Function to create the employee table
def create_table():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            role TEXT NOT NULL,
            salary REAL NOT NULL,
            dob TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Create the employee table on application startup
create_table()

# Endpoint to insert a new employee record
@app.route('/employeesrec', methods=['POST'])
def add_employee():
    data = request.get_json()
    name = data.get('name')
    role = data.get('role')
    salary = data.get('salary')
    dob = data.get('dob')

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('INSERT INTO employees (name, role, salary, dob) VALUES (?, ?, ?, ?)', (name, role, salary, dob))
    conn.commit()
    conn.close()

    return jsonify({'message': 'Employee added successfully'}), 201

# Endpoint to get all employees
@app.route('/employees', methods=['GET'])
def get_employees():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM employees')
    employees = cursor.fetchall()
    conn.close()

    employee_list = []
    for employee in employees:
        employee_data = {
            'id': employee[0],
            'name': employee[1],
            'role': employee[2],
            'salary': employee[3],
            'dob': employee[4]
        }
        employee_list.append(employee_data)

    return jsonify({'employees': employee_list}), 200

# Endpoint to update an employee record by id
@app.route('/employees/<int:id>', methods=['PUT'])
def update_employee(id):
    data = request.get_json()
    name = data.get('name')
    role = data.get('role')
    salary = data.get('salary')
    dob = data.get('dob')

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('UPDATE employees SET name=?, role=?, salary=?, dob=? WHERE id=?', (name, role, salary, dob, id))
    conn.commit()
    conn.close()

    return jsonify({'message': 'Employee updated successfully'}), 200

# Endpoint to delete an employee record by id
@app.route('/employees/<int:id>', methods=['DELETE'])
def delete_employee(id):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM employees WHERE id=?', (id,))
    conn.commit()
    conn.close()

    return jsonify({'message': 'Employee deleted successfully'}), 200


# Endpoint to get an employee by ID
@app.route('/employees/<int:id>', methods=['GET'])
def get_employee_by_id(id):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM employees WHERE id=?', (id,))
    employee = cursor.fetchone()
    conn.close()

    if employee:
        employee_data = {
            'id': employee[0],
            'name': employee[1],
            'role': employee[2],
            'salary': employee[3],
            'dob': employee[4]
        }
        return jsonify({'employee': employee_data}), 200
    else:
        return jsonify({'message': 'Employee not found'}), 404

# Endpoint to get employees by name
@app.route('/employees/by_name/<string:name>', methods=['GET'])
def get_employees_by_name(name):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM employees WHERE name=?', (name,))
    employees = cursor.fetchall()
    conn.close()

    if employees:
        employee_list = []
        for employee in employees:
            employee_data = {
                'id': employee[0],
                'name': employee[1],
                'role': employee[2],
                'salary': employee[3],
                'dob': employee[4]
            }
            employee_list.append(employee_data)

        return jsonify({'employees': employee_list}), 200
    else:
        return jsonify({'message': 'Employees not found'}), 404

# Endpoint to get employees by role
@app.route('/employees/by_role/<string:role>', methods=['GET'])
def get_employees_by_role(role):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM employees WHERE role=?', (role,))
    employees = cursor.fetchall()
    conn.close()

    if employees:
        employee_list = []
        for employee in employees:
            employee_data = {
                'id': employee[0],
                'name': employee[1],
                'role': employee[2],
                'salary': employee[3],
                'dob': employee[4]
            }
            employee_list.append(employee_data)

        return jsonify({'employees': employee_list}), 200
    else:
        return jsonify({'message': 'Employees not found'}), 404

# Endpoint to get employees by salary (greater than or equal to a specified value)
@app.route('/employees/by_salary/<float:salary>', methods=['GET'])
def get_employees_by_salary(salary):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM employees WHERE salary >= ?', (salary,))
    employees = cursor.fetchall()
    conn.close()

    if employees:
        employee_list = []
        for employee in employees:
            employee_data = {
                'id': employee[0],
                'name': employee[1],
                'role': employee[2],
                'salary': employee[3],
                'dob': employee[4]
            }
            employee_list.append(employee_data)

        return jsonify({'employees': employee_list}), 200
    else:
        return jsonify({'message': 'Employees not found'}), 404


if __name__ == '__main__':
    app.run(debug=True)
